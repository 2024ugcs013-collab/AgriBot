from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Dict, List

import numpy as np
import tensorflow as tf
from PIL import Image

CLASS_NAMES = ["Potato___Early_blight", "Potato___Late_blight", "Potato___healthy"]
IMAGE_SIZE = (256, 256)


def _get_model_path() -> Path:
    # app/model_service.py -> FastAPI/app -> root
    return Path(__file__).resolve().parents[2] / "models" / "saved"


@lru_cache(maxsize=1)
def load_model() -> tf.keras.Model:
    model_path = _get_model_path()
    if not model_path.exists():
        raise FileNotFoundError(f"Saved model directory not found: {model_path}")
    return tf.keras.models.load_model(model_path)


def preprocess_image(image: Image.Image) -> np.ndarray:
    rgb = image.convert("RGB")
    resized = rgb.resize(IMAGE_SIZE)
    array = np.asarray(resized, dtype=np.float32) / 255.0
    return np.expand_dims(array, axis=0)


def predict(image: Image.Image) -> Dict[str, object]:
    model = load_model()
    input_batch = preprocess_image(image)
    logits = model.predict(input_batch, verbose=0)

    if logits.ndim == 2 and logits.shape[0] == 1:
        logits = logits[0]

    probs = tf.nn.softmax(logits).numpy()
    class_idx = int(np.argmax(probs))
    confidence = float(probs[class_idx])

    all_probs: List[Dict[str, float]] = [
        {"class_name": CLASS_NAMES[i], "probability": float(probs[i])}
        for i in range(min(len(CLASS_NAMES), len(probs)))
    ]

    return {
        "predicted_class": CLASS_NAMES[class_idx],
        "confidence": confidence,
        "probabilities": all_probs,
    }
