# Potato Disease Classification (FastAPI + React)

This project classifies potato leaf diseases from images using a trained TensorFlow SavedModel.

## Classes

- Potato___Early_blight
- Potato___Late_blight
- Potato___healthy

## 1) Backend Setup and Run

Open a terminal at the project root and run:
```
pip install -r requirements.txt
python main.py
```

## 2) Frontend Setup and Run

Open a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

## API Endpoints

- GET `/`
   - returns welcome message
- GET `/health`
   - returns API health status
- POST `/predict`
   - accepts one image in multipart form-data with field name `file`
   - returns JSON prediction result

Example response:

```json
{
   "predicted_class": "Potato___Late_blight",
   "confidence": 0.9842,
   "probabilities": [
      { "class_name": "Potato___Early_blight", "probability": 0.0031 },
      { "class_name": "Potato___Late_blight", "probability": 0.9842 },
      { "class_name": "Potato___healthy", "probability": 0.0127 }
   ]
}
```

## Model Notes

- Saved model path used by backend: `models/saved/`
- Default preprocessing in backend:
   - converts image to RGB
   - resizes to 256 x 256
   - normalizes pixels to [0, 1]

If your trained model expects a different image size, update `IMAGE_SIZE` in `FastAPI/app/model_service.py`.
