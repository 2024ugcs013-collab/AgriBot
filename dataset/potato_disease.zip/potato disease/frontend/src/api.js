const API_BASE = "http://127.0.0.1:8000";

export async function predictDisease(file) {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${API_BASE}/predict`, {
    method: "POST",
    body: formData,
  });

  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload.detail || "Prediction failed.");
  }

  return payload;
}
