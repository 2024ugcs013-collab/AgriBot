import { useEffect, useMemo, useState } from "react";
import { predictDisease } from "./api";

function toPercent(value) {
  return `${(value * 100).toFixed(2)}%`;
}

export default function App() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  const topPrediction = useMemo(() => {
    if (!result) return null;
    return `${result.predicted_class.replace("Potato___", "").replace("_", " ")} (${toPercent(result.confidence)})`;
  }, [result]);

  function onFileChange(event) {
    const file = event.target.files?.[0] || null;
    setSelectedFile(file);
    setResult(null);
    setError("");

    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }

    if (file) {
      setPreviewUrl(URL.createObjectURL(file));
    } else {
      setPreviewUrl("");
    }
  }

  async function onSubmit(event) {
    event.preventDefault();

    if (!selectedFile) {
      setError("Please choose an image first.");
      return;
    }

    try {
      setLoading(true);
      setError("");
      const data = await predictDisease(selectedFile);
      setResult(data);
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={`page-shell ${previewUrl ? "has-image" : ""}`}>
      {previewUrl ? (
        <div
          className="background-image"
          style={{ backgroundImage: `url(${previewUrl})` }}
          aria-hidden="true"
        />
      ) : null}
      <div className="glow glow-a" />
      <div className="glow glow-b" />

      <main className="layout">
        <section className="card hero-card">
          <p className="eyebrow">Potato AI Lab</p>
          <h1>Leaf Disease Detector</h1>
          <p className="subtext">
            Upload one potato leaf image and get instant classification from your trained TensorFlow model.
          </p>

          <form className="uploader" onSubmit={onSubmit}>
            <label className="file-label" htmlFor="leaf-upload">
              Choose Leaf Image
            </label>
            <input
              id="leaf-upload"
              type="file"
              accept="image/*"
              onChange={onFileChange}
            />
            <button type="submit" className="predict-btn" disabled={loading}>
              {loading ? "Classifying..." : "Predict Disease"}
            </button>
          </form>

          {error ? <p className="error-msg">{error}</p> : null}
        </section>

        <section className="card result-card">
          <h2>Result</h2>

          {previewUrl ? (
            <img className="preview" src={previewUrl} alt="Selected potato leaf" />
          ) : (
            <div className="preview placeholder">Image preview appears here</div>
          )}

          {result ? (
            <div className="result-block">
              <p className="top-result">{topPrediction}</p>
              <ul className="prob-list">
                {result.probabilities.map((item) => (
                  <li key={item.class_name}>
                    <span>{item.class_name.replace("Potato___", "").replace("_", " ")}</span>
                    <strong>{toPercent(item.probability)}</strong>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <p className="hint">Run a prediction to view confidence scores.</p>
          )}
        </section>
      </main>
    </div>
  );
}
